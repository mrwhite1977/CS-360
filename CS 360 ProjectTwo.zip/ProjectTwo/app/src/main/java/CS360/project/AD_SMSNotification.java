package CS360.project;

import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

public class AD_SMSNotification {

    public static AlertDialog doubleButton(final ItemListActivity context){
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setIcon(R.drawable.sms_notification)
                .setCancelable(false)
                .setMessage(R.string.SMStext)
                .setPositiveButton(R.string.ad_sms_enable_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts Enable", Toast.LENGTH_LONG).show();
                    ItemListActivity.AllowSendSMS();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.ad_sms_disable_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts Disable", Toast.LENGTH_LONG).show();
                    ItemListActivity.DenySendSMS();
                    dialog.cancel();
                });

        // Create the AlertDialog object and return it
        return builder.create();
    }
}